CMSC5714 LZW Compressor (2014 Ver.)

Win32 Executable Sample Program

File List:
=======================================
LZW.exe: LZW Sample program

(Compression)
LZW.exe -c <output> <list of files>

(Decompression)
LZW.exe -d <compressed file>
=======================================
Zero.exe: Generate a file with many zeros

Zero.exe <output> <file size in byte>
=======================================
Timer.exe: To calculate the execute time of program

Timer.exe <program> <arguments>
